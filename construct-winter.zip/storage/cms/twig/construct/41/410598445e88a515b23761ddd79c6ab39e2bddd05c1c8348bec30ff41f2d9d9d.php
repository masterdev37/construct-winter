<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\banner.htm */
class __TwigTemplate_5d5fb7393d1b55e43645ee0173ee167d6f6661dec058fe5210016032b6aac8b5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-banner\" id=\"s-banner\">
\t\t
\t\t<div class=\"swiper banner-swiper\">
\t\t\t
\t\t\t<div class=\"swiper-wrapper\">
\t\t\t\t";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 6), "banner_slider", [], "any", false, false, true, 6));
        foreach ($context['_seq'] as $context["_key"] => $context["banner"]) {
            // line 7
            echo "\t\t\t\t\t<div class=\"swiper-slide\" style=\"background-image: url(";
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["banner"], "banner_image", [], "any", false, false, true, 7), 7, $this->source)), "html", null, true);
            echo ")\">
\t\t\t\t\t\t<div class=\"banner-content\">
\t\t\t\t\t\t\t<div class=\"banner-subtitle\">";
            // line 9
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["banner"], "banner_subtitle", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t<h2 class=\"banner-title\">";
            // line 10
            echo $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["banner"], "banner_title", [], "any", false, false, true, 10), 10, $this->source);
            echo "</h2>
\t\t\t\t\t\t\t<a href=\"";
            // line 11
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 11), "banner_btn_link", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
            echo "\" class=\"banner-btn def-btn anchor-link\">
\t\t\t\t\t\t\t\t";
            // line 12
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 12), "banner_btn_text", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['banner'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "\t\t\t</div>

\t\t\t<div class=\"swiper-pagination\"></div>
\t\t\t
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"swiper-button-prev\"></div>
\t\t\t\t<div class=\"swiper-button-next\"></div>
\t\t\t</div>
\t\t
\t\t</div>

\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\banner.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 17,  68 => 12,  64 => 11,  60 => 10,  56 => 9,  50 => 7,  46 => 6,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-banner\" id=\"s-banner\">
\t\t
\t\t<div class=\"swiper banner-swiper\">
\t\t\t
\t\t\t<div class=\"swiper-wrapper\">
\t\t\t\t{% for banner in this.theme.banner_slider %}
\t\t\t\t\t<div class=\"swiper-slide\" style=\"background-image: url({{ banner.banner_image | media }})\">
\t\t\t\t\t\t<div class=\"banner-content\">
\t\t\t\t\t\t\t<div class=\"banner-subtitle\">{{ banner.banner_subtitle }}</div>
\t\t\t\t\t\t\t<h2 class=\"banner-title\">{{ banner.banner_title | raw }}</h2>
\t\t\t\t\t\t\t<a href=\"{{ this.theme.banner_btn_link }}\" class=\"banner-btn def-btn anchor-link\">
\t\t\t\t\t\t\t\t{{ this.theme.banner_btn_text }}
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endfor %}
\t\t\t</div>

\t\t\t<div class=\"swiper-pagination\"></div>
\t\t\t
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"swiper-button-prev\"></div>
\t\t\t\t<div class=\"swiper-button-next\"></div>
\t\t\t</div>
\t\t
\t\t</div>

\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\banner.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 6);
        static $filters = array("escape" => 7, "media" => 7, "raw" => 10);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'media', 'raw'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
