<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\services.htm */
class __TwigTemplate_e64d4d940f46b97e143b54e640eed40d4bc64a8e7734521c77cef44010adcc3e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-services\" id=\"s-services\">
\t\t<div class=\"container\">
\t\t\t<h2 class=\"center-title\">";
        // line 3
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 3), "services_title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
        echo "</h2>

\t\t\t<div class=\"services-row\">

\t\t\t\t";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 7), "services_loop", [], "any", false, false, true, 7));
        foreach ($context['_seq'] as $context["_key"] => $context["services"]) {
            // line 8
            echo "\t\t\t\t\t<div class=\"services-item\">
\t\t\t\t\t\t<div class=\"services-thumb\">
\t\t\t\t\t\t\t<img src=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["services"], "services_item_image", [], "any", false, false, true, 10), 10, $this->source)), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["services"], "services_title", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
            echo "\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"services-body\">
\t\t\t\t\t\t\t<h4 class=\"services-title\">";
            // line 13
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["services"], "services_item_title", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
            echo "</h4>
\t\t\t\t\t\t\t<a href=\"#modal-form\" data-effect=\"mfp-zoom-in\" class=\"def-btn services-btn modal-btn\">";
            // line 14
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 14), "services_btn_text", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            echo "</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['services'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "
\t\t\t\t

\t\t\t</div>
\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\services.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  70 => 14,  66 => 13,  58 => 10,  54 => 8,  50 => 7,  43 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-services\" id=\"s-services\">
\t\t<div class=\"container\">
\t\t\t<h2 class=\"center-title\">{{ this.theme.services_title }}</h2>

\t\t\t<div class=\"services-row\">

\t\t\t\t{% for services in this.theme.services_loop %}
\t\t\t\t\t<div class=\"services-item\">
\t\t\t\t\t\t<div class=\"services-thumb\">
\t\t\t\t\t\t\t<img src=\"{{ services.services_item_image | media }}\" alt=\"{{ services.services_title }}\">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"services-body\">
\t\t\t\t\t\t\t<h4 class=\"services-title\">{{ services.services_item_title }}</h4>
\t\t\t\t\t\t\t<a href=\"#modal-form\" data-effect=\"mfp-zoom-in\" class=\"def-btn services-btn modal-btn\">{{ this.theme.services_btn_text }}</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endfor %}

\t\t\t\t

\t\t\t</div>
\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\services.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 7);
        static $filters = array("escape" => 3, "media" => 10);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'media'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
