<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\numbers.htm */
class __TwigTemplate_9a0b16c17220af150194b5651e68c8284c4229c3e0a4fa9940f2a3ab49977de9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-numbers\" id=\"s-numbers\">
\t\t<div class=\"container\">
\t\t\t<div class=\"numbers-row\">

\t\t\t\t<div class=\"numbers-left\">
\t\t\t\t\t<h2 class=\"def-title color-white\">";
        // line 6
        echo $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 6), "numbers_title", [], "any", false, false, true, 6), 6, $this->source);
        echo "</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t";
        // line 8
        echo $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 8), "numbers_desc", [], "any", false, false, true, 8), 8, $this->source);
        echo "
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"numbers-right\">
\t\t\t\t\t";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 13), "numbers_loop", [], "any", false, false, true, 13));
        foreach ($context['_seq'] as $context["_key"] => $context["numbers"]) {
            // line 14
            echo "\t\t\t\t\t\t<div class=\"numbers-item\">
\t\t\t\t\t\t\t<div class=\"numbers-num\">";
            // line 15
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["numbers"], "numbers_num_item", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t<div class=\"numbers-desc\">
\t\t\t\t\t\t\t\t";
            // line 17
            echo $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["numbers"], "numbers_num_title", [], "any", false, false, true, 17), 17, $this->source);
            echo "
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['numbers'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "\t\t\t\t</div>

\t\t\t</div>
\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\numbers.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 21,  71 => 17,  66 => 15,  63 => 14,  59 => 13,  51 => 8,  46 => 6,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-numbers\" id=\"s-numbers\">
\t\t<div class=\"container\">
\t\t\t<div class=\"numbers-row\">

\t\t\t\t<div class=\"numbers-left\">
\t\t\t\t\t<h2 class=\"def-title color-white\">{{ this.theme.numbers_title | raw }}</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t{{ this.theme.numbers_desc | raw }}
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"numbers-right\">
\t\t\t\t\t{% for numbers in this.theme.numbers_loop %}
\t\t\t\t\t\t<div class=\"numbers-item\">
\t\t\t\t\t\t\t<div class=\"numbers-num\">{{ numbers.numbers_num_item }}</div>
\t\t\t\t\t\t\t<div class=\"numbers-desc\">
\t\t\t\t\t\t\t\t{{ numbers.numbers_num_title | raw }}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endfor %}
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\numbers.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 13);
        static $filters = array("raw" => 6, "escape" => 15);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['raw', 'escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
