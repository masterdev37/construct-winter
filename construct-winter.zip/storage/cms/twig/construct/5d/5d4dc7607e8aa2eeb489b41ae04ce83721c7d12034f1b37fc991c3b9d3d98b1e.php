<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\reviews.htm */
class __TwigTemplate_f17a8fbcc2b878bf896d5ba1940a8477521ad57ca119a50e9c105d1b97c5d8de extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-reviews\" id=\"s-reviews\" style=\"background-image: url('";
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 1), "reviews_background", [], "any", false, false, true, 1), 1, $this->source)), "html", null, true);
        echo "');\">
\t\t<div class=\"container\">
\t\t\t<h2 class=\"center-title color-white\">";
        // line 3
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 3), "reviews_title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
        echo "</h2>
\t\t\t
\t\t\t<div class=\"swiper reviews-swiper\">
\t\t\t\t
\t\t\t\t<div class=\"swiper-wrapper\">

\t\t\t\t\t";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 9), "reviews_loop", [], "any", false, false, true, 9));
        foreach ($context['_seq'] as $context["_key"] => $context["reviews"]) {
            // line 10
            echo "\t\t\t\t\t\t<div class=\"swiper-slide\">
\t\t\t\t\t\t\t<div class=\"reviews-item\">
\t\t\t\t\t\t\t\t<div class=\"reviews-thumb\">
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_item_image", [], "any", false, false, true, 13), 13, $this->source)), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_item_name", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t\t<div class=\"reviews-body\">
\t\t\t\t\t\t\t\t\t<div class=\"reviews-name\">";
            // line 17
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_item_name", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-profi\">";
            // line 18
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_item_profi", [], "any", false, false, true, 18), 18, $this->source), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-comment\">
\t\t\t\t\t\t\t\t\t\t";
            // line 20
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_item_desc", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-social\">
\t\t\t\t\t\t\t\t\t\t";
            // line 23
            if (twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_vk", [], "any", false, false, true, 23)) {
                // line 24
                echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_vk", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
                echo "\" target=\"_blank\"><img src=\"";
                echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/social-vk-gray.svg");
                echo "\" alt=\"Вконтакте\"></a>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 26
            echo "
\t\t\t\t\t\t\t\t\t\t";
            // line 27
            if (twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_facebook", [], "any", false, false, true, 27)) {
                // line 28
                echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_facebook", [], "any", false, false, true, 28), 28, $this->source), "html", null, true);
                echo "\"><img src=\"";
                echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/social-facebook-gray.svg");
                echo "\" alt=\"Facebook\" target=\"_blank\"></a>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 30
            echo "
\t\t\t\t\t\t\t\t\t\t";
            // line 31
            if (twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_telegram", [], "any", false, false, true, 31)) {
                // line 32
                echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["reviews"], "reviews_social_link_telegram", [], "any", false, false, true, 32), 32, $this->source), "html", null, true);
                echo "\"><img src=\"";
                echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/social-telegram-gray.svg");
                echo "\" alt=\"Telegram\" target=\"_blank\"></a>
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 34
            echo "\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reviews'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "
\t\t\t\t\t

\t\t\t\t</div>
\t\t\t
\t\t\t\t<div class=\"swiper-pagination\"></div>
\t\t\t
\t\t\t</div>

\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\reviews.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 40,  123 => 34,  115 => 32,  113 => 31,  110 => 30,  102 => 28,  100 => 27,  97 => 26,  89 => 24,  87 => 23,  81 => 20,  76 => 18,  72 => 17,  63 => 13,  58 => 10,  54 => 9,  45 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-reviews\" id=\"s-reviews\" style=\"background-image: url('{{ this.theme.reviews_background | media }}');\">
\t\t<div class=\"container\">
\t\t\t<h2 class=\"center-title color-white\">{{ this.theme.reviews_title }}</h2>
\t\t\t
\t\t\t<div class=\"swiper reviews-swiper\">
\t\t\t\t
\t\t\t\t<div class=\"swiper-wrapper\">

\t\t\t\t\t{% for reviews in this.theme.reviews_loop %}
\t\t\t\t\t\t<div class=\"swiper-slide\">
\t\t\t\t\t\t\t<div class=\"reviews-item\">
\t\t\t\t\t\t\t\t<div class=\"reviews-thumb\">
\t\t\t\t\t\t\t\t\t<img src=\"{{ reviews.reviews_item_image | media }}\" alt=\"{{ reviews.reviews_item_name }}\">
\t\t\t\t\t\t\t\t</div>
\t
\t\t\t\t\t\t\t\t<div class=\"reviews-body\">
\t\t\t\t\t\t\t\t\t<div class=\"reviews-name\">{{ reviews.reviews_item_name }}</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-profi\">{{ reviews.reviews_item_profi }}</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-comment\">
\t\t\t\t\t\t\t\t\t\t{{ reviews.reviews_item_desc }}
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"reviews-social\">
\t\t\t\t\t\t\t\t\t\t{% if reviews.reviews_social_link_vk %}
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ reviews.reviews_social_link_vk }}\" target=\"_blank\"><img src=\"{{ 'assets/images/social-vk-gray.svg' | theme }}\" alt=\"Вконтакте\"></a>
\t\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t\t{% if reviews.reviews_social_link_facebook %}
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ reviews.reviews_social_link_facebook }}\"><img src=\"{{ 'assets/images/social-facebook-gray.svg' | theme }}\" alt=\"Facebook\" target=\"_blank\"></a>
\t\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t\t{% if reviews.reviews_social_link_telegram %}
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ reviews.reviews_social_link_telegram }}\"><img src=\"{{ 'assets/images/social-telegram-gray.svg' | theme }}\" alt=\"Telegram\" target=\"_blank\"></a>
\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endfor %}

\t\t\t\t\t

\t\t\t\t</div>
\t\t\t
\t\t\t\t<div class=\"swiper-pagination\"></div>
\t\t\t
\t\t\t</div>

\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\reviews.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 9, "if" => 23);
        static $filters = array("escape" => 1, "media" => 1, "theme" => 24);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'media', 'theme'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
