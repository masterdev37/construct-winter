<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\about.htm */
class __TwigTemplate_e3e9ac6224c8029846c776a204d43c6f1e1df9d2916a6a25453920664172bc11 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-about\" id=\"s-about\">
\t\t<div class=\"container\">

\t\t\t<div class=\"about-row\">
\t\t\t\t<div class=\"about-left\">
\t\t\t\t\t<h2 class=\"def-title\">";
        // line 6
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 6), "about_title", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        echo "</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t";
        // line 8
        echo $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 8), "about_desc", [], "any", false, false, true, 8), 8, $this->source);
        echo "
\t\t\t\t\t</div>
\t\t\t\t\t<a href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 10), "about_btn_link", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
        echo "\" data-effect=\"mfp-zoom-in\" class=\"def-btn modal-btn\">";
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 10), "about_btn_text", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
        echo "</a>
\t\t\t\t</div>
\t
\t\t\t\t<div class=\"about-right\">
\t\t\t\t\t<img src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 14), "about_image", [], "any", false, false, true, 14), 14, $this->source)), "html", null, true);
        echo "\" alt=\"О нас\">
\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\about.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 14,  56 => 10,  51 => 8,  46 => 6,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-about\" id=\"s-about\">
\t\t<div class=\"container\">

\t\t\t<div class=\"about-row\">
\t\t\t\t<div class=\"about-left\">
\t\t\t\t\t<h2 class=\"def-title\">{{ this.theme.about_title }}</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t{{ this.theme.about_desc | raw }}
\t\t\t\t\t</div>
\t\t\t\t\t<a href=\"{{ this.theme.about_btn_link }}\" data-effect=\"mfp-zoom-in\" class=\"def-btn modal-btn\">{{ this.theme.about_btn_text }}</a>
\t\t\t\t</div>
\t
\t\t\t\t<div class=\"about-right\">
\t\t\t\t\t<img src=\"{{ this.theme.about_image | media }}\" alt=\"О нас\">
\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\about.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array();
        static $filters = array("escape" => 6, "raw" => 8, "media" => 14);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape', 'raw', 'media'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
