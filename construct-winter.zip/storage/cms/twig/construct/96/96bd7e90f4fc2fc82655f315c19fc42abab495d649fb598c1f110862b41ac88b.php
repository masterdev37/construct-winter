<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\gallery.htm */
class __TwigTemplate_09fe55f503c2af2664e78c9b9e2f1b04636fb435485dde7e8703b294545bf93c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-gallery\" id=\"s-gallery\">
\t\t<div class=\"container\">
\t\t\t<div class=\"center-title\">";
        // line 3
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 3), "gallery_title", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
        echo "</div>

\t\t\t<div class=\"gallery-wrap\">
\t\t\t\t";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 6), "gallery_loop", [], "any", false, false, true, 6));
        foreach ($context['_seq'] as $context["_key"] => $context["gallery"]) {
            // line 7
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["gallery"], "gallery_image", [], "any", false, false, true, 7), 7, $this->source)), "html", null, true);
            echo "\" class=\"gallery-item\" data-effect=\"mfp-zoom-in\">
\t\t\t\t\t\t<span class=\"gallery-border\"></span>
\t\t\t\t\t\t<img src=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["gallery"], "gallery_image", [], "any", false, false, true, 9), 9, $this->source)), "html", null, true);
            echo "\" alt=\"Изображение\">
\t\t\t\t\t</a>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gallery'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "\t\t\t</div>

\t\t\t<div class=\"gallery-btn\">
\t\t\t\t<a href=\"#\" class=\"def-btn\">Показать еще</a>
\t\t\t</div>
\t\t\t
\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\gallery.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 12,  59 => 9,  53 => 7,  49 => 6,  43 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-gallery\" id=\"s-gallery\">
\t\t<div class=\"container\">
\t\t\t<div class=\"center-title\">{{ this.theme.gallery_title }}</div>

\t\t\t<div class=\"gallery-wrap\">
\t\t\t\t{% for gallery in this.theme.gallery_loop %}
\t\t\t\t\t<a href=\"{{ gallery.gallery_image | media }}\" class=\"gallery-item\" data-effect=\"mfp-zoom-in\">
\t\t\t\t\t\t<span class=\"gallery-border\"></span>
\t\t\t\t\t\t<img src=\"{{ gallery.gallery_image | media }}\" alt=\"Изображение\">
\t\t\t\t\t</a>
\t\t\t\t{% endfor %}
\t\t\t</div>

\t\t\t<div class=\"gallery-btn\">
\t\t\t\t<a href=\"#\" class=\"def-btn\">Показать еще</a>
\t\t\t</div>
\t\t\t
\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\gallery.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 6);
        static $filters = array("escape" => 3, "media" => 7);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'media'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
