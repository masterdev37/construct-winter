<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\why.htm */
class __TwigTemplate_56b5a526007bdbc1f5c30ede4ec2b8f3d5a30930a75eecf60b55956b92b39093 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section class=\"s-why\" id=\"s-why\">
\t\t<div class=\"container\">
\t\t\t<div class=\"why-row\">

\t\t\t\t<div class=\"why-left\">
\t\t\t\t\t<h2 class=\"def-title\">";
        // line 6
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 6), "why_title", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        echo "</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t";
        // line 8
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 8), "why_desc", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
        echo "
\t\t\t\t\t</div>
\t
\t\t\t\t\t<div class=\"why-features\">

\t\t\t\t\t\t";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 13), "why_list", [], "any", false, false, true, 13));
        foreach ($context['_seq'] as $context["_key"] => $context["why"]) {
            // line 14
            echo "\t\t\t\t\t\t\t<div class=\"why-features-item\">
\t\t\t\t\t\t\t\t<div class=\"why-features-icon\">
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 16
            echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/check-mark.svg");
            echo "\" alt=\"Check mark\">
\t\t\t\t\t\t\t\t</div>
\t\t
\t\t\t\t\t\t\t\t<div class=\"why-features-right\">
\t\t\t\t\t\t\t\t\t<div class=\"why-features-title\">";
            // line 20
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["why"], "why_list_title", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
            echo "</div>
\t\t\t\t\t\t\t\t\t<div class=\"why-features-desc\">
\t\t\t\t\t\t\t\t\t\t";
            // line 22
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["why"], "why_list_desc", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['why'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "\t
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"why-right\">
\t\t\t\t\t<img src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 32), "why_image", [], "any", false, false, true, 32), 32, $this->source)), "html", null, true);
        echo "\" alt=\"Почему мы?\">
\t\t\t\t</div>
\t\t\t\t
\t\t\t</div>
\t\t</div>
\t</section>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\why.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 32,  90 => 27,  79 => 22,  74 => 20,  67 => 16,  63 => 14,  59 => 13,  51 => 8,  46 => 6,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"s-why\" id=\"s-why\">
\t\t<div class=\"container\">
\t\t\t<div class=\"why-row\">

\t\t\t\t<div class=\"why-left\">
\t\t\t\t\t<h2 class=\"def-title\">{{ this.theme.why_title }}</h2>
\t\t\t\t\t<div class=\"def-desc\">
\t\t\t\t\t\t{{ this.theme.why_desc }}
\t\t\t\t\t</div>
\t
\t\t\t\t\t<div class=\"why-features\">

\t\t\t\t\t\t{% for why in this.theme.why_list %}
\t\t\t\t\t\t\t<div class=\"why-features-item\">
\t\t\t\t\t\t\t\t<div class=\"why-features-icon\">
\t\t\t\t\t\t\t\t\t<img src=\"{{ 'assets/images/check-mark.svg' | theme }}\" alt=\"Check mark\">
\t\t\t\t\t\t\t\t</div>
\t\t
\t\t\t\t\t\t\t\t<div class=\"why-features-right\">
\t\t\t\t\t\t\t\t\t<div class=\"why-features-title\">{{ why.why_list_title }}</div>
\t\t\t\t\t\t\t\t\t<div class=\"why-features-desc\">
\t\t\t\t\t\t\t\t\t\t{{ why.why_list_desc }}
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"why-right\">
\t\t\t\t\t<img src=\"{{ this.theme.why_image | media }}\" alt=\"Почему мы?\">
\t\t\t\t</div>
\t\t\t\t
\t\t\t</div>
\t\t</div>
\t</section>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\why.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 13);
        static $filters = array("escape" => 6, "theme" => 16, "media" => 32);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'theme', 'media'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
