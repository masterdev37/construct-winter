<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\OSPanel\domains\construct-winter\themes\construct\partials\header.htm */
class __TwigTemplate_014a59f2f1919025758371ef778aa23e18d847e1c398f50877c9881bdc5c662e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<div class=\"modal-form mfp-hide mfp-with-anim\" id=\"modal-form\">

\t\t<div class=\"modal-form-head\">
\t\t\t<div class=\"modal-form-logo\">
\t\t\t\t<img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 5), "logo_header", [], "any", false, false, true, 5), 5, $this->source)), "html", null, true);
        echo "\" alt=\"Construction\">
\t\t\t</div>
\t\t\t<div class=\"modal-form-close\">
\t\t\t\t<img src=\"";
        // line 8
        echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/close.svg");
        echo "\" alt=\"Close\">
\t\t\t</div>
\t\t</div>

\t\t<div class=\"modal-form-body\">
\t\t\t<div class=\"modal-form-title\">Заказать звонок</div>
\t\t\t<form data-request=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(($context["contactForm"] ?? null), 14, $this->source), "html", null, true);
        echo "::onFormSubmit\">
\t\t\t\t";
        // line 15
        echo $this->env->getFunction('form_token')->getCallable()("token");
        echo "
\t\t\t\t<div id=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(($context["contactForm"] ?? null), 16, $this->source), "html", null, true);
        echo "_forms_flash\"></div>
\t\t\t\t<input id=\"service-name\" type=\"hidden\" name=\"Название услуги\" value=\"\">
\t\t\t\t<input type=\"text\" placeholder=\"Ваше имя*\" name=\"Имя\" required>
\t\t\t\t<input type=\"text\" placeholder=\"Ваше телефон*\" name=\"Телефон\" required>
\t\t\t\t<button class=\"form-button\">Отправить</button>
\t\t\t</form>
\t\t</div>

\t</div>
\t
\t<header class=\"site-header\">
\t\t<div class=\"header-top\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"header-row\">

\t\t\t\t\t<!-- Header top mobile START -->
\t\t\t\t\t<div class=\"header-mobile-logo\">
\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t<img src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 34), "logo_header", [], "any", false, false, true, 34), 34, $this->source)), "html", null, true);
        echo "\" alt=\"Construction\">
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"hamburger\">
\t\t\t\t\t\t<span></span>
\t\t\t\t\t\t<span></span>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- Header top mobile END -->

\t\t\t\t\t<div class=\"header-desc\">";
        // line 44
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 44), "company_activiy", [], "any", false, false, true, 44), 44, $this->source), "html", null, true);
        echo "</div>
\t\t\t\t\t<div class=\"header-right\">
\t\t\t\t\t\t<div class=\"header-info\">
\t\t\t\t\t\t\t<img src=\"";
        // line 47
        echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/location.svg");
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 47), "address", [], "any", false, false, true, 47), 47, $this->source), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t<span>";
        // line 48
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 48), "address", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<a href=\"tel:";
        // line 50
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 50), "address", [], "any", false, false, true, 50), 50, $this->source), "html", null, true);
        echo "\" class=\"header-info\">
\t\t\t\t\t\t\t<img src=\"";
        // line 51
        echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/phone.svg");
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 51), "address", [], "any", false, false, true, 51), 51, $this->source), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t<span>";
        // line 52
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 52), "phone", [], "any", false, false, true, 52), 52, $this->source), "html", null, true);
        echo "</span>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<div class=\"header-social\">
\t\t\t\t\t\t\t";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 56), "social_networks", [], "any", false, false, true, 56));
        foreach ($context['_seq'] as $context["_key"] => $context["social"]) {
            // line 57
            echo "\t\t\t\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "social_link", [], "any", false, false, true, 57), 57, $this->source), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "social_icon", [], "any", false, false, true, 58), 58, $this->source)), "html", null, true);
            echo "\" alt=\"Twitter\">
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['social'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"header-bottom\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"header-bottom-row\">
\t\t\t\t\t<div class=\"header-logo\">
\t\t\t\t\t\t<a href=\"/\">
\t\t\t\t\t\t\t<img src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 72), "logo_header", [], "any", false, false, true, 72), 72, $this->source)), "html", null, true);
        echo "\" alt=\"Construction\">
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>

\t\t\t\t\t<nav class=\"header-nav\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 78), "header_menu", [], "any", false, false, true, 78));
        foreach ($context['_seq'] as $context["_key"] => $context["header_menu"]) {
            // line 79
            echo "\t\t\t\t\t\t\t\t<li><a class=\"anchor-link\" href=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["header_menu"], "header_menu_link", [], "any", false, false, true, 79), 79, $this->source), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["header_menu"], "header_menu_name", [], "any", false, false, true, 79), 79, $this->source), "html", null, true);
            echo "</a></li>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['header_menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 81
        echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</nav>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>


\t\t<!-- Header mobile START -->
\t\t<div class=\"header-mobile-wrap\">
\t\t\t<nav class=\"header-mobile-nav\">
\t\t\t\t<ul>
\t\t\t\t\t";
        // line 92
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 92), "header_menu", [], "any", false, false, true, 92));
        foreach ($context['_seq'] as $context["_key"] => $context["header_menu"]) {
            // line 93
            echo "\t\t\t\t\t\t<li><a href=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["header_menu"], "header_menu_link", [], "any", false, false, true, 93), 93, $this->source), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["header_menu"], "header_menu_name", [], "any", false, false, true, 93), 93, $this->source), "html", null, true);
            echo "</a></li>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['header_menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 95
        echo "\t\t\t\t</ul>
\t\t\t</nav>

\t\t\t<div class=\"header-mobile-info\">
\t\t\t\t<img src=\"";
        // line 99
        echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/location.svg");
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 99), "address", [], "any", false, false, true, 99), 99, $this->source), "html", null, true);
        echo "\">
\t\t\t\t<span>";
        // line 100
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 100), "address", [], "any", false, false, true, 100), 100, $this->source), "html", null, true);
        echo "</span>
\t\t\t</div>
\t\t\t<a href=\"tel:+7 950 457 5654\" class=\"header-mobile-info\">
\t\t\t\t<img src=\"";
        // line 103
        echo $this->extensions['Cms\Twig\Extension']->themeFilter("assets/images/phone.svg");
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 103), "address", [], "any", false, false, true, 103), 103, $this->source), "html", null, true);
        echo "\">
\t\t\t\t<span>";
        // line 104
        echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 104), "phone", [], "any", false, false, true, 104), 104, $this->source), "html", null, true);
        echo "</span>
\t\t\t</a>


\t\t\t<div class=\"header-mobile-social\">
\t\t\t\t";
        // line 109
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["this"] ?? null), "theme", [], "any", false, false, true, 109), "social_networks", [], "any", false, false, true, 109));
        foreach ($context['_seq'] as $context["_key"] => $context["social"]) {
            // line 110
            echo "\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "social_link", [], "any", false, false, true, 110), 110, $this->source), "html", null, true);
            echo "\">
\t\t\t\t\t\t<img src=\"";
            // line 111
            echo twig_escape_filter($this->env, $this->extensions['System\Twig\Extension']->mediaFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, $context["social"], "social_icon", [], "any", false, false, true, 111), 111, $this->source)), "html", null, true);
            echo "\" alt=\"Twitter\">
\t\t\t\t\t</a>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['social'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 114
        echo "\t\t\t</div>
\t\t</div>
\t\t<!-- Header mobile END -->

\t</header>";
    }

    public function getTemplateName()
    {
        return "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\header.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  269 => 114,  260 => 111,  255 => 110,  251 => 109,  243 => 104,  237 => 103,  231 => 100,  225 => 99,  219 => 95,  208 => 93,  204 => 92,  191 => 81,  180 => 79,  176 => 78,  167 => 72,  154 => 61,  145 => 58,  140 => 57,  136 => 56,  129 => 52,  123 => 51,  119 => 50,  114 => 48,  108 => 47,  102 => 44,  89 => 34,  68 => 16,  64 => 15,  60 => 14,  51 => 8,  45 => 5,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"modal-form mfp-hide mfp-with-anim\" id=\"modal-form\">

\t\t<div class=\"modal-form-head\">
\t\t\t<div class=\"modal-form-logo\">
\t\t\t\t<img src=\"{{ this.theme.logo_header | media }}\" alt=\"Construction\">
\t\t\t</div>
\t\t\t<div class=\"modal-form-close\">
\t\t\t\t<img src=\"{{ 'assets/images/close.svg' | theme }}\" alt=\"Close\">
\t\t\t</div>
\t\t</div>

\t\t<div class=\"modal-form-body\">
\t\t\t<div class=\"modal-form-title\">Заказать звонок</div>
\t\t\t<form data-request=\"{{ contactForm }}::onFormSubmit\">
\t\t\t\t{{ form_token() }}
\t\t\t\t<div id=\"{{ contactForm }}_forms_flash\"></div>
\t\t\t\t<input id=\"service-name\" type=\"hidden\" name=\"Название услуги\" value=\"\">
\t\t\t\t<input type=\"text\" placeholder=\"Ваше имя*\" name=\"Имя\" required>
\t\t\t\t<input type=\"text\" placeholder=\"Ваше телефон*\" name=\"Телефон\" required>
\t\t\t\t<button class=\"form-button\">Отправить</button>
\t\t\t</form>
\t\t</div>

\t</div>
\t
\t<header class=\"site-header\">
\t\t<div class=\"header-top\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"header-row\">

\t\t\t\t\t<!-- Header top mobile START -->
\t\t\t\t\t<div class=\"header-mobile-logo\">
\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t<img src=\"{{ this.theme.logo_header | media }}\" alt=\"Construction\">
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"hamburger\">
\t\t\t\t\t\t<span></span>
\t\t\t\t\t\t<span></span>
\t\t\t\t\t</div>
\t\t\t\t\t<!-- Header top mobile END -->

\t\t\t\t\t<div class=\"header-desc\">{{ this.theme.company_activiy }}</div>
\t\t\t\t\t<div class=\"header-right\">
\t\t\t\t\t\t<div class=\"header-info\">
\t\t\t\t\t\t\t<img src=\"{{ 'assets/images/location.svg'|theme }}\" alt=\"{{ this.theme.address }}\">
\t\t\t\t\t\t\t<span>{{ this.theme.address }}</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<a href=\"tel:{{ this.theme.address }}\" class=\"header-info\">
\t\t\t\t\t\t\t<img src=\"{{ 'assets/images/phone.svg'|theme }}\" alt=\"{{ this.theme.address }}\">
\t\t\t\t\t\t\t<span>{{ this.theme.phone }}</span>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t<div class=\"header-social\">
\t\t\t\t\t\t\t{% for social in this.theme.social_networks %}
\t\t\t\t\t\t\t\t<a href=\"{{ social.social_link }}\">
\t\t\t\t\t\t\t\t\t<img src=\"{{ social.social_icon | media }}\" alt=\"Twitter\">
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"header-bottom\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"header-bottom-row\">
\t\t\t\t\t<div class=\"header-logo\">
\t\t\t\t\t\t<a href=\"/\">
\t\t\t\t\t\t\t<img src=\"{{ this.theme.logo_header | media }}\" alt=\"Construction\">
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>

\t\t\t\t\t<nav class=\"header-nav\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t{% for header_menu in this.theme.header_menu %}
\t\t\t\t\t\t\t\t<li><a class=\"anchor-link\" href=\"{{ header_menu.header_menu_link }}\">{{ header_menu.header_menu_name }}</a></li>
\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t</ul>
\t\t\t\t\t</nav>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>


\t\t<!-- Header mobile START -->
\t\t<div class=\"header-mobile-wrap\">
\t\t\t<nav class=\"header-mobile-nav\">
\t\t\t\t<ul>
\t\t\t\t\t{% for header_menu in this.theme.header_menu %}
\t\t\t\t\t\t<li><a href=\"{{ header_menu.header_menu_link }}\">{{ header_menu.header_menu_name }}</a></li>
\t\t\t\t\t{% endfor %}
\t\t\t\t</ul>
\t\t\t</nav>

\t\t\t<div class=\"header-mobile-info\">
\t\t\t\t<img src=\"{{ 'assets/images/location.svg'|theme }}\" alt=\"{{ this.theme.address }}\">
\t\t\t\t<span>{{ this.theme.address }}</span>
\t\t\t</div>
\t\t\t<a href=\"tel:+7 950 457 5654\" class=\"header-mobile-info\">
\t\t\t\t<img src=\"{{ 'assets/images/phone.svg'|theme }}\" alt=\"{{ this.theme.address }}\">
\t\t\t\t<span>{{ this.theme.phone }}</span>
\t\t\t</a>


\t\t\t<div class=\"header-mobile-social\">
\t\t\t\t{% for social in this.theme.social_networks %}
\t\t\t\t\t<a href=\"{{ social.social_link }}\">
\t\t\t\t\t\t<img src=\"{{ social.social_icon | media }}\" alt=\"Twitter\">
\t\t\t\t\t</a>
\t\t\t\t{% endfor %}
\t\t\t</div>
\t\t</div>
\t\t<!-- Header mobile END -->

\t</header>", "C:\\OSPanel\\domains\\construct-winter\\themes\\construct\\partials\\header.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = array("for" => 56);
        static $filters = array("escape" => 5, "media" => 5, "theme" => 8);
        static $functions = array("form_token" => 15);

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'media', 'theme'],
                ['form_token']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
