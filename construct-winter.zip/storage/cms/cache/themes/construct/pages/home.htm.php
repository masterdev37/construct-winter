<?php 
class Cms64e0e309c1af7028007388_b6de4ff548e04d33918f8931e02907cdClass extends Cms\Classes\PageCode
{

}
