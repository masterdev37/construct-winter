<?php 
class Cms64e0e30a2e172070393985_b039ff405d1942337876863801565ff1Class extends Cms\Classes\PartialCode
{

}
