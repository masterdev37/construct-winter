<?php 
class Cms64e1d373a663f802595889_8b3e40dfc17f2e3af5c119774c63c46bClass extends Cms\Classes\PartialCode
{

}
