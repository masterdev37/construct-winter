<?php 
class Cms64e0e6c3666e6145216492_dab066dc9b37ece74709f16564da1756Class extends Cms\Classes\PartialCode
{

}
