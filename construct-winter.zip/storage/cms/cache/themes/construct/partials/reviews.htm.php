<?php 
class Cms64e1ff00c2398534994686_bab49da570a2ed00df065a5c03f583aeClass extends Cms\Classes\PartialCode
{

}
