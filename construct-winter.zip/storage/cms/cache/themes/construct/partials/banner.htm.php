<?php 
class Cms64e1d2be263d8228146861_3088ac6cfcd23d9134942964c2805f4aClass extends Cms\Classes\PartialCode
{

}
