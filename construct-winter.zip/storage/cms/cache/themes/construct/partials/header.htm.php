<?php 
class Cms64e1d4e15bae0159142864_a91d55bca8898775ed2fb9f585883f7eClass extends Cms\Classes\PartialCode
{

}
