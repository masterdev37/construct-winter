<?php 
class Cms64e0e30a08eee971432950_36e614b2b94c4dfc1b998d1f9456d34fClass extends Cms\Classes\PartialCode
{

}
