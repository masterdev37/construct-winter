<?php 
class Cms64e2023eec7cc013808850_57d212df231db16cdca106f47b7f894dClass extends Cms\Classes\PartialCode
{

}
