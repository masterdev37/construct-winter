<?php 
class Cms64e0e30a277f7683016256_f0bef7c63624873a44a25941cc27a2fcClass extends Cms\Classes\PartialCode
{

}
