<?php 
class Cms64e0e30a4ced4089172257_d22891a2596568c6b9319059d9344214Class extends Cms\Classes\PartialCode
{

}
