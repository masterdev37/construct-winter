<?php 
class Cms64e0e30a1c121306893384_ddc027a9584cdce31e39e3ce492bbc0aClass extends Cms\Classes\PartialCode
{

}
