<?php 
class Cms64e1d37387c04399697436_b39eb3a4d5c244260a4bac1bdc50556bClass extends Cms\Classes\PartialCode
{

}
