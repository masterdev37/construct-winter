
<p>
    <?= e(trans('backend::lang.access_log.hint', ['days' => 60])) ?>
</p>