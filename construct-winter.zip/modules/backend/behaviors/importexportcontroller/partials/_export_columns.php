<div class="export-columns" id="exportColumns">
    <div class="control-simplelist with-checkboxes is-sortable" data-control="simplelist">
        <ul>
            <?php foreach ($exportColumns as $key => $column): ?>
                <li>
                    <div class="checkbox custom-checkbox">
                        <input
                            type="hidden"
                            name="export_columns[]"
                            value="<?= $key ?>" />
                        <input
                            id="<?= $this->getId('exportCheckbox-'.$key) ?>"
                            name="visible_columns[<?= $key ?>]"
                            value="1"
                            checked="checked"
                            type="checkbox" />
                        <label
                            class="choice"
                            for="<?= $this->getId('exportCheckbox-'.$key) ?>">
                                <?= e(trans($column)) ?>
                        </label>
                    </div>
                </li>
            <?php endforeach ?>
        </ul>
    </div>
</div>