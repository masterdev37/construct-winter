<div
    id="<?= $this->relationGetId() ?>"
    data-request-data="_relation_field: '<?= $relationField ?>', _relation_extra_config: '<?= e(base64_encode(json_encode($relationExtraConfig))) ?>'"
    class="relation-behavior relation-view-<?= $relationViewMode ?>">

    <?php if ($toolbar = $this->relationRenderToolbar()): ?>
        <!-- Relation Toolbar -->
        <div id="<?= $this->relationGetId('toolbar') ?>" class="relation-toolbar">
            <?= $toolbar ?>
        </div>
    <?php endif ?>

    <!-- Relation View -->
    <div id="<?= $this->relationGetId('view') ?>" class="relation-manager">
        <?= $this->relationRenderView() ?>
    </div>

</div>
