<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonCreate"
    href="javascript:;"
    class="btn btn-sm btn-secondary wn-icon-file">
    <?= e(trans($text, ['name' => trans($relationLabel)])) ?>
</a>
