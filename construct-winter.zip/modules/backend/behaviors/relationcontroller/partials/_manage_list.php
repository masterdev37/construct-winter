<div id="relationManagePopup" data-request-data="_relation_field: '<?= $relationField ?>', _relation_mode: 'list'">
    <?= Form::open() ?>
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="popup">&times;</button>
            <h4 class="modal-title"><?= e(trans($relationManageTitle, [
                'name' => trans($relationLabel)
            ])) ?></h4>
        </div>

        <div class="list-flush">
            <?php if ($relationSearchWidget): ?>
                <?= $relationSearchWidget->render() ?>
            <?php endif ?>
            <?php if ($relationManageFilterWidget): ?>
                <?= $relationManageFilterWidget->render() ?>
            <?php endif ?>
            <?= $relationManageWidget->render() ?>
        </div>

        <div class="modal-footer">
            <?php if ($relationManageWidget->showCheckboxes): ?>
                <button
                    type="button"
                    class="btn btn-primary"
                    data-request="onRelationManageAdd"
                    data-dismiss="popup"
                    data-request-success="$.wn.relationBehavior.changed('<?= e($relationField) ?>', 'added')"
                    data-stripe-load-indicator>
                    <?= e(trans('backend::lang.relation.add_selected')) ?>
                </button>
            <?php endif ?>
            <button
                type="button"
                class="btn btn-default"
                data-dismiss="popup">
                <?= e(trans('backend::lang.relation.cancel')) ?>
            </button>
        </div>
    <?= Form::close() ?>
</div>
