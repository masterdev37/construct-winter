<a
    data-control="popup"
    data-size="huge"
    data-handler="onRelationButtonAdd"
    href="javascript:;"
    class="btn btn-sm btn-secondary wn-icon-plus">
    <?= e(trans($text, ['name' => trans($relationLabel)])) ?>
</a>
