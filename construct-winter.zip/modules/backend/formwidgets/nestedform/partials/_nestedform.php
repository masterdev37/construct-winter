<div class="nested-form <?= $this->usePanelStyles ? 'panel-styles' : '' ?>">
    <?= $this->formWidget->render() ?>
</div>
